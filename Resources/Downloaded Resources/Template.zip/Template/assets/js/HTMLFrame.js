function getCookie(cname) {
       var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function ChangeEncodedTextByAJAX(id, address)
{
    $.ajax({
        type:'post', 
        url:address,
        async:true,
        dataType:'text',
        data:'',
        success:function(res) {document.getElementById(id).innerHTML = decodeURI(res);}
    })
}
function ChangeTextByAJAX(id, address)
{
    $.ajax({
        type:'post', 
        url:address,
        async:false,
        dataType:'text',
        data:'',
        success:function(res) {document.getElementById(id).innerHTML = res;}
    })
}
function GetTextByAJAX(address)
{
    var ans;
    $.ajax({
        type:'get', 
        url:address,
        async:false,
        success:function(res) {ans = res}
    })
    return ans;
}

// Hex
var HexDecode = function (hex) {
	var arr = hex.split("")
	var out = ""
	for (var i = 0; i < arr.length / 2; i++) {
		var tmp = "0x" + arr[i * 2] + arr[i * 2 + 1]
		var charValue = String.fromCharCode(tmp);
		out += charValue;
	}
return out
};
var HexEncode = function (str) {
	var val = "";
	for (var i = 0; i < str.length; i++) {
		if (val == "")
			val = str.charCodeAt(i).toString(16);
		else
			val += str.charCodeAt(i).toString(16);
	}
	val += "0a"
	return val
}